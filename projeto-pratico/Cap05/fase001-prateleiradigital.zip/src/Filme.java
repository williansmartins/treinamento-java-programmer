public class Filme {

		private String titulo;
		private String diretores;
		private double nota;
		private int duracao;
		private int ano;
		private String generos;
		private int numVotos;
		private String url;
		

}
